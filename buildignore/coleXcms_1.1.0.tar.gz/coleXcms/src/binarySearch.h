int lowerBound(double val,double *mzval,int first, int length);
int upperBound(double val,double *mzval,int first, int length);
